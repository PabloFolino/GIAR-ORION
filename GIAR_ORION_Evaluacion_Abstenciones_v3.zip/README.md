# GIAR-ORION — Evaluación de abstenciones v3

## Contenido
- `abstention_eval_v3.py`: clasificador explicable que usa pregunta + respuesta.
- `casos_controlados_40_v3.json`: 40 casos v2; A31 queda marcado para revisión, sin relabelado automático.
- `casos_reales_48_v3.json`: 48 respuestas de la evaluación previa, con pregunta, respuesta y fragmentos recuperados.
- `run_abstention_eval_v3.py`: ejecuta ambas evaluaciones y guarda JSON detallados.

## Ejecutar en Windows
Copiar esta carpeta al proyecto (como carpeta de pruebas separada) y ejecutar con el Python del entorno virtual: `python .\run_abstention_eval_v3.py`. No reemplaza archivos del agente.

## Interpretación
- No modifica el RAG, el LLM ni `ResponseVerifier.py`.
- Las etiquetas esperadas de las 48 respuestas se heredan de la evaluación anterior y no son una referencia independiente validada.
- `partial` indica incertidumbre combinada con contexto; no determina por sí solo si la respuesta es correcta.
- `grounding_review_required` señala que una afirmación específica necesita cotejo con `retrieved_fragments`; no certifica que sea falsa.
- La evaluación de fundamentación no se automatiza por completo en esta versión. Revisar manualmente los desacuerdos y los casos parciales antes de modificar reglas.
