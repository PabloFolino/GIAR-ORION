# GIAR-ORION — Evaluación de abstenciones v2

- `abstention_eval_v2.py`: clasificador heurístico de tres estados (`abstention`, `partial`, `answer`) y métricas TP/TN/FP/FN.
- `casos_abstencion_controlados_v2.json`: 40 casos etiquetados manualmente.
- `run_abstention_eval.py`: ejecuta la prueba y genera `resultado_prueba_abstenciones_v2.json`.

## Ejecución
```powershell
python .\run_abstention_eval.py
```

## Integración sugerida
No sobrescribir inmediatamente el campo histórico `detected_abstention`. Agregar campos nuevos `detected_abstention_v2`, `abstention_status_v2`, `abstention_reason_v2` y `abstention_confidence_v2`, comparar v1/v2 y revisar manualmente los desacuerdos.

## Limitaciones
El set de 40 casos es controlado y fue construido para cubrir abstenciones explícitas, respuestas válidas con incertidumbre parcial y casos mixtos. No equivale a una evaluación humana ni mide veracidad factual. La heurística puede fallar ante paráfrasis, negaciones complejas y respuestas largas. Debe usarse como métrica auxiliar; la fundamentación factual requiere una evaluación aparte.
