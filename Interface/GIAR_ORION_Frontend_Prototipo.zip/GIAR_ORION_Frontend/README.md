# GIAR-ORION — Prototipo Frontend

Prototipo navegable de la interfaz multiagente basado en la referencia visual aportada.

## Ejecutar
1. Descomprimir la carpeta.
2. Abrir `index.html` en un navegador, o abrir la carpeta en Visual Studio Code.
3. Para desarrollo, se puede utilizar la extensión Live Server de VS Code.

## Archivos
- `index.html`: estructura de la interfaz.
- `css/styles.css`: estilos y adaptación responsive.
- `js/app.js`: interacciones de demostración.

## Interacciones incluidas
- Selección de los seis agentes.
- Cambio del modo de conversación.
- Envío de mensajes con respuesta simulada.
- Acciones rápidas que completan el campo de mensaje.
- Creación de conversaciones.
- Navegación superior con respuestas informativas de demostración.

## Límites de esta versión
Es únicamente el frontend de demostración. No incluye API, persistencia, conexión a Ollama ni integración con `main_multilinea.py`. Los avatares son representaciones gráficas temporales; podrán sustituirse por los recursos visuales definitivos.
